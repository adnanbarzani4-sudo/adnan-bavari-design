ADNAN BAVARI DESIGN — CLOUDFLARE PAGES
=====================================

ئەم وەشانە بۆ Cloudflare Pages ئامادە کراوە.
- گەلەری گشتی: /
- پەڕەی لۆگۆ: /logo.html?id=001
- پانێڵی Admin: /admin.html
- زانیارییەکان: Cloudflare D1
- وێنەکان: Cloudflare R2
- واتسئاپ: +9647506950563

گرنگ: تەنیا ZIP ـەکە لە خانەی Upload static assets دابنێ مەکە؛ ئەم پرۆژەیە Pages Functions ـی تێدایە و پێویستی بە Git integration یان Wrangler CLI هەیە.

هەنگاوەکانی دامەزراندن:
1) ZIP ـەکە بکەرەوە و هەموو فایلەکان بخەرە ناو GitHub repository.
2) لە Cloudflare Dashboard بچۆ بۆ Workers & Pages > Create application > Pages > Connect to Git.
3) Repository ـی پرۆژەکە هەڵبژێرە.
4) Build command بەتاڵ بهێڵە و Build output directory بنووسە: public
5) دوای دروستبوونی Pages project، لە Settings > Bindings، D1 database binding زیاد بکە بە ناوی DB و database ـی adnan-bavari-db.
6) R2 bucket binding زیاد بکە بە ناوی LOGOS و bucket ـی adnan-bavari-logos.
7) لە Settings > Variables and Secrets، secret ـێک زیاد بکە بە ناوی ADMIN_PASSWORD و وشەیەکی نهێنی بەهێز دابنێ.
8) D1 database دروست بکە و SQL ـی migrations/0001_create_products.sql جێبەجێ بکە.
9) Deploy بکە و /admin.html بکەرەوە.

D1 SQL:
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  data TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

پێویستە binding ـەکان بە هەمان ناوەکانی DB و LOGOS دابنرێن؛ گۆڕینی ناوەکان API ـەکان دەشکێنێت.

پاراستن:
- وشەی نهێنی تەنیا لە Cloudflare Secret دابنێ؛ لە کۆد یان GitHub مەینووسە.
- ئەم سایتە تەنیا پیشاندانی بەرهەمە؛ پارەدان لەسەر سایت نییە.
- بۆ بەکارهێنانی 200+ لۆگۆ، باشترە وێنەکان webp یان jpg و کەمتر لە 3MB بن.
