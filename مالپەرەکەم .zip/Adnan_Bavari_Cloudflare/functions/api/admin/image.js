export async function onRequestPost({ request, env }) {
  if (!env.ADMIN_PASSWORD || request.headers.get("x-admin-password") !== env.ADMIN_PASSWORD)
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  const body = await request.json().catch(() => ({}));
  if (!body.id || typeof body.data !== "string") return Response.json({ error: "Image data is invalid." }, { status: 400 });
  const match = body.data.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return Response.json({ error: "تەنیا PNG/JPG/WEBP ڕێگەپێدراوە." }, { status: 400 });
  const binary = atob(match[2]);
  if (binary.length > 3 * 1024 * 1024) return Response.json({ error: "وێنەکە زۆر گەورەیە؛ کەمتر لە ٣ MB." }, { status: 413 });
  const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
  const ext = match[1] === "image/png" ? "png" : match[1] === "image/webp" ? "webp" : "jpg";
  const key = `${String(body.id).replace(/[^a-zA-Z0-9_-]/g, "_")}.${ext}`;
  await env.LOGOS.put(key, bytes, { httpMetadata: { contentType: match[1], cacheControl: "public, max-age=31536000, immutable" } });
  return Response.json({ url: `/api/image/${encodeURIComponent(key)}` });
}
