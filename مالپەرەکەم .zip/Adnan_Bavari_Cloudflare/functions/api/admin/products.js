function authorized(request, env) {
  const expected = env.ADMIN_PASSWORD;
  return !!expected && request.headers.get("x-admin-password") === expected;
}
export async function onRequest({ request, env }) {
  if (!authorized(request, env)) return Response.json({ error: "وشەی نهێنی هەڵەیە یان لە Cloudflare ڕێکنەخراوە." }, { status: 401 });
  if (request.method === "GET") {
    const { results = [] } = await env.DB.prepare("SELECT data FROM products ORDER BY created_at DESC").all();
    return Response.json(results.map(r => JSON.parse(r.data)));
  }
  if (request.method === "PUT") {
    const body = await request.json().catch(() => ({}));
    if (!Array.isArray(body.products)) return Response.json({ error: "داتاکان نادروستن." }, { status: 400 });
    const ids = new Set();
    for (const p of body.products) {
      if (!p || !p.id || typeof p.id !== "string" || ids.has(p.id)) return Response.json({ error: "هەموو لۆگۆکان دەبێت ID ـی جیاوازیان هەبێت." }, { status: 400 });
      ids.add(p.id);
    }
    await env.DB.batch([
      env.DB.prepare("DELETE FROM products"),
      ...body.products.map(p => env.DB.prepare("INSERT INTO products (id, data, created_at) VALUES (?, ?, datetime('now'))").bind(p.id, JSON.stringify(p)))
    ]);
    return Response.json({ ok: true });
  }
  if (request.method === "DELETE") {
    const body = await request.json().catch(() => ({}));
    if (!body.id) return Response.json({ error: "ID پێویستە." }, { status: 400 });
    await env.DB.prepare("DELETE FROM products WHERE id = ?").bind(String(body.id)).run();
    return Response.json({ ok: true });
  }
  return new Response("Method Not Allowed", { status: 405, headers: { Allow: "GET, PUT, DELETE" } });
}
