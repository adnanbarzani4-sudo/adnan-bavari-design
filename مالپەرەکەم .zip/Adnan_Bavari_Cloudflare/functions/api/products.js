export async function onRequestGet({ env }) {
  const { results = [] } = await env.DB.prepare("SELECT data FROM products ORDER BY created_at DESC").all();
  const products = results.map(row => { try { return JSON.parse(row.data); } catch { return null; } }).filter(Boolean);
  return Response.json(products, { headers: { "Cache-Control": "public, max-age=30" } });
}
