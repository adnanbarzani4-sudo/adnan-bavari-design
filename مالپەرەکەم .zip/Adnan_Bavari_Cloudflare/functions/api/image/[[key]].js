export async function onRequest({ params, env }) {
  const key = Array.isArray(params.key) ? params.key.join("/") : params.key;
  if (!key || key.includes("..")) return new Response("Not found", { status: 404 });
  const object = await env.LOGOS.get(key);
  if (!object) return new Response("Not found", { status: 404 });
  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);
  headers.set("Cache-Control", "public, max-age=31536000, immutable");
  return new Response(object.body, { headers });
}
